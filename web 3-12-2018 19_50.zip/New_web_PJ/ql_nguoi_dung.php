<div class="center">			
	<table class="p_table">
		<tr id="headline" style="background-color: #0C1C83; color: white;">
			<td>ID người dùng</td>
			<td>Loai Tk</td>
			<td>Tên đăng nhập</td>
			<td>Mật khẩu</td>
			<td>Email</td>
		</tr>
		<?php 
			$query = "SELECT * FROM user";
			$result = mysqli_query($db,$query);
			if(mysqli_num_rows($result) > 0):
				while($row = mysqli_fetch_array($result)): ?>
		<tr>
			<td><?php echo $row["id"] ?></td>
			<td><?php echo $row["loai"]; ?></td>
			<td><?php echo $row["username"] ?></td>
			<td><?php echo $row["password"] ?></td>
			<td><?php echo $row["email"] ?></td>
		</tr>
		<?php endwhile; endif;  ?>
	</table>



</div>
