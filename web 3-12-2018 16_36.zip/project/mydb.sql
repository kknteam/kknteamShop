-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2018 at 06:41 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `ctsanpham`
--

CREATE TABLE `ctsanpham` (
  `id_sp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `giam_gia` int(11) DEFAULT NULL,
  `mo_ta` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `gioi_thieu` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `chi_tiet` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `chi_tiet_1` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bao_hanh` int(11) NOT NULL,
  `thuong_hieu` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mau_sac` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tuong_thich` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ctsanpham`
--

INSERT INTO `ctsanpham` (`id_sp`, `id`, `giam_gia`, `mo_ta`, `gioi_thieu`, `chi_tiet`, `chi_tiet_1`, `bao_hanh`, `thuong_hieu`, `label`, `mau_sac`, `loai`, `tuong_thich`) VALUES
('CT_HP01', 'HP01', 20, '<p>Tích hợp soundcard với âm thanh giả lập 7.1</p>\r\n<p>Đáp tuyến tần số: 15Hz–25.000 Hz</p>\r\n<p>Trở kháng danh nghĩa: 60 Ω trên mỗi hệ thống</p>\r\n<p>Ngưỡng áp suất âm (SPL) danh nghĩa: 98±3dB</p>\r\n<p>Độ giảm tiếng ồn xung quanh: khoảng 20 dBa</p>', 'Năm 1987, Kingston® đã tiếp cận thị trường chỉ với một sản phẩm đơn lẻ. Hai nhà sáng lập John Tu và David Sun đã giải quyết tình trạng thiếu hụt nghiêm trọng chip nhớ gắn trên bề mặt bằng một module bộ nhớ, giúp định nghĩa lại các tiêu chuẩn trong ngành công nghiệp bộ nhớ trong những năm sau đó.', 'Tai Nghe Kingston HyperX Cloud II được thiết kế dành cho các game thủ với nhiều màu sắc khác nhau cho bạn lựa chọn. Phần chụp đầu và chụp tai có những lớp đệm mềm mại êm ái mang lại cảm giác thoải mái khi sử dụng trong một thời gian dài. Bên cạnh đó, tai nghe còn tích hợp loa HiFi 53mm và âm thanh vòm 7.1 mang đến cho bạn những âm thanh tuyệt hảo nhất.', 'Chụp đầu của tai nghe được làm từ chất liệu giả da mang đến cảm giác thoải mái cho người dùng. Phần chụp tai ôn gọn lấy đôi tai của bạn giúp bạn cách lý với tiếng ồn xung quanh để có thể nghe được những tiếng động trong game. Ngoài ra, thiết kế mạnh mẽ mang đậm chất game chắc chắn sẽ làm các game thủ thích thú hơn với chiếc tai nghe này.', 12, 'Kingston', 'HPX II 7.1', 'Đen, đỏ', 'Có dây', 'Giác căm 3.5mm'),
('CT_KB03', 'KB03', 10, '<p>- Loại tai nghe: Tai nghe chụp đầu </p>\r\n<p>- Khối lượng: 300 gram</p>\r\n<p>- Kết nối: jack cắm 3.5mm</p>\r\n<p>- Tốc độ phản hồi: 500hz/1ms</p>\r\n<p>- Thiết kế: chụp tai </p>\r\n<p>- Phụ kiền đi kèm: không có</p>', 'Giới thiệu về Corsair\r\n                        Corsair Components, Inc. (được cách điệu là CORSAIR) là một công ty phần cứng và thiết bị ngoại vi máy tính của Mỹ có trụ sở tại Fremont, California. Công ty được thành lập tại California vào tháng 1 năm 1994 và được tái hợp nhất tại Delaware vào năm 2007. Ngoài trụ sở chính ở Fremont, California, Corsair duy trì một cơ sở sản xuất tại thành phố Đào Viên, Đài Loan, để lắp ráp, thử nghiệm và đóng gói các sản phẩm chọn lọc, và quản lý phân phối khu vực châu Á, Hoa Kỳ và châu Âu. Họ cũng đặt nhiều văn phòng bán hàng và tiếp thị trên khắp nước Mỹ cũng như một số quốc gia châu Âu và châu Á.', 'Là loại bàn phím cơ không dây với layout tenkeless (lược bỏ phần numpad) gọn gàng  cùng với khối lượng chỉ 1,09kg, chúng ta có thể hiểu khá rõ ràng ý đồ thiết kế Corsair \r\n                                                K63 Wireless là phục vụ tiện lợi tối đa cho nhu cầu di động. Tất nhiên, khác với thiết\r\n                                                kế của một bàn phím có dây truyền thống, Corsair K63 Wireless có thêm 2 đèn báo nguồn \r\n                                                và sóng không dây, bên cạnh đèn capslock và scroll-lock.', 'Với đèn báo nguồn hiển thị màu trắng là pin đang hoạt động bình thường, màu đỏ là pin đã gần cạn nhắc nhở chúng ta cần cắm sạc. Và đèn báo sóng không dây sẽ hiển thị màu trắng khi đang sử dụng chế độ Wireless, màu xanh dương khi đang sử dụng chế độ Bluetooth. Các bạn có thể chuyển đổi giữa 2 chế độ sóng không dây một cách đơn giản bằng tổ hợp phím FN+F9 cho Wireless, FN+F10 cho Bluetooth.', 24, 'Cosair', 'K63', 'Đen', 'Không dây', 'Tất cả');

-- --------------------------------------------------------

--
-- Table structure for table `phan_quyen`
--

CREATE TABLE `phan_quyen` (
  `ID_loai` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `phan_quyen`
--

INSERT INTO `phan_quyen` (`ID_loai`, `loai`) VALUES
('A', 'admin'),
('U', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `STT` int(11) NOT NULL,
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `productname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `img` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `img_1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_2` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngay_nhan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`STT`, `id`, `productname`, `price`, `img`, `img_1`, `img_2`, `ngay_nhan`) VALUES
(1, 'HP01', 'Headphone Hyper X', 350000, 'HP01.jpg', 'HP01_1.jpg', 'HP01_2.jpg', '2018-10-09'),
(2, 'KB01', 'Fuhlen J60', 850000, 'KB01.jpg', '', '', '2018-10-01'),
(3, 'KB02', 'Bàn phím Glorious GMMK', 550000, 'KB02.jpg', '', '', '2018-10-02'),
(4, 'KB03', 'Bàn phím Cosair', 1200000, 'KB03_1.jpg', 'KB03_1.jpg', 'KB03_2.jpg', '2018-10-03'),
(5, 'Lap01', 'ASUS F555L Laptop', 14350000, 'Lap01.jpg', '', '', '2018-10-04'),
(6, 'Moni01', '69inch Mega Monitor', 1200000, 'Moni01.jpg', '', '', '2018-10-05'),
(7, 'Mse01', 'Razor Mouse', 1100000, 'Mouse01.jpg', '', '', '2018-10-07'),
(8, 'Mse02', 'Gamming Mouse', 800000, 'Mouse02.jpg', '', '', '2018-10-08'),
(9, 'PC01', 'Gamming PC', 11000000, 'PC01.jpg', '', '', '2018-11-02'),
(10, 'PC02', 'FullSet Gamming PC', 15000000, 'PC02.jpg', '', '', '2018-11-20');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `loai` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `loai`, `username`, `password`, `email`) VALUES
(0, 'A', 'admin', '4297f44b13955235245b2497399d7a93', 'admin@gmail.com'),
(1, 'A', 'employ01', '4297f44b13955235245b2497399d7a93', 'employ01@gmail.com'),
(2, 'A', 'BossKhang', '4297f44b13955235245b2497399d7a93', 'haduykhang109@gmail.com'),
(3, 'A', 'employ02', '4297f44b13955235245b2497399d7a93', 'employ02@gmail.com'),
(4, 'U', 'Long', '4297f44b13955235245b2497399d7a93', 'long@gmail.com'),
(5, 'U', 'ChoKhang', 'e10adc3949ba59abbe56e057f20f883e', 'chokhang@sforum.vn');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ctsanpham`
--
ALTER TABLE `ctsanpham`
  ADD PRIMARY KEY (`id_sp`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `phan_quyen`
--
ALTER TABLE `phan_quyen`
  ADD PRIMARY KEY (`ID_loai`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `STT` (`STT`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loai` (`loai`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`loai`) REFERENCES `phan_quyen` (`ID_loai`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
