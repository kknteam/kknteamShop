<?php if(isset($_SESSION['username'])) : ?>
    <?php 
        $name = $_SESSION['username'];
        $query = "SELECT loai FROM user WHERE username = '$name'";
        $result = mysqli_query($db, $query);
        while($row = mysqli_fetch_array($result)):
    ?>
    <div class="admin">
        <ul type="none"> 
            <li><a href="#">Xin chào <strong> <?php echo $_SESSION['username']; ?></strong></a></li>
                <?php if($row['loai'] == 'A'): ?>
                    <li><a href="index.php?a=ql_nguoi_dung.php"> Quản lý người dùng</a></li>
                    <li><a href="index.php?a=ql_sanPham.php">Quản lý sản phẩm</a></li>                           
                <?php endif ?>
            <li><a style="float: right;" href="login.php?logout='1'">Đăng xuất</a></li>
        </ul>                
    </div>
    <?php endwhile; ?>
<?php endif ?> 