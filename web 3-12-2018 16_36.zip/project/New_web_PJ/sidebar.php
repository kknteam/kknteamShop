             
              <div class="sidebar">
                <dl>
                  <dt>Check out our product</dt>         
                        <dd>
                          <a href="index.php?a=ItemSort.php&pid=Lap">Laptop</a>
                        </dd>
                        <dd>
                          <a href="index.php?a=ItemSort.php&pid=HP">Headphone</a>
                        </dd>
                        <dd>
                          <a href="index.php?a=ItemSort.php&pid=KB">Keyboard</a>
                        </dd>
                        <dd>
                          <a href="index.php?a=ItemSort.php&pid=Mse">Mouse</a>
                        </dd>
                        <dd>
                          <a href="index.php?a=ItemSort.php&pid=Moni">Monitor</a>
                        </dd>
                </dl>

                <hr>
                <div class="dropdown">
                    <button>Your Cart</button>
                    <div class="dropdown-content"><?php include("subPage/cart.php"); ?></div>
                </div>
            </div>