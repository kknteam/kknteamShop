<div class="nav">
                    <ul>
                        <li id="lft"><a class="active" href="index.php?a=index01.php">HOME PAGE</a></li>
                        <li id="lft"><a href="index.php?a=about.php">ABOUT</a></li>
                        <li id="lft"><a href="index.php?a=contact.php">CONTACT</a></li>
                        
                        <li style="color: #FC2121; background-color: #F9B3B3; float: right;"><?php include("subPage/numberCartItem.php");?></li>
                        <li id="rgt"><a href="checkout.php"><i style="font-size:20px" class="fa">&#xf07a;</i></a></li>
                        <li id="rgt"><a href="signup.php">Sign up</a></li>  
                        <li id="rgt"><a href="login.php">Log in</a></li>                 
                    </ul>

</div>